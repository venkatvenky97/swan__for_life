import React from "react";
import { useLocation } from "react-router";
import { NavLink } from "react-router-dom";
import SVG from "react-inlinesvg";
import { toAbsoluteUrl, checkIsActive } from "../../../../_helpers";

export function AsideMenuList({ layoutProps }) {
    const location = useLocation();
    const getMenuItemActive = (url, hasSubmenu = false) => {
        return checkIsActive(location, url) ? ` ${!hasSubmenu && "menu-item-active"} menu-item-open menu-item-not-hightlighted` : "";
    };
    const getActiveSvg = (url, hasSubmenu = false) => {
        return checkIsActive(location, url) ? `svg-icon-dark` : `svg-icon-success`;
    };

    return ( 
        <> 
            <ul className={`menu-nav ${layoutProps.ulClasses}`}>
                <li className={`menu-item ${getMenuItemActive("/overview", false)}`} aria-haspopup="true">
                    <NavLink className="menu-link" to="/overview">
                        <span className={`svg-icon ${getActiveSvg("/overview", false)}`}>
                            <SVG src={toAbsoluteUrl("/icons/Home.svg")} />
                        </span>
                        <span className="menu-text">Overview</span>
                    </NavLink>
                </li>
                <li className={`menu-item ${getMenuItemActive("/clients", false)}`} aria-haspopup="true">
                    <NavLink className="menu-link" to="/clients">
                        <span className={`svg-icon ${getActiveSvg("/clients", false)}`}>
                            <SVG src={toAbsoluteUrl("/icons/Group.svg")} />
                        </span>
                        <span className="menu-text">Clients</span>
                    </NavLink>
                </li>
                <li className={`menu-item ${getMenuItemActive("/policies", false)}`} aria-haspopup="true">
                    <NavLink className="menu-link" to="/policies">
                        <span className={`svg-icon ${getActiveSvg("/policies", false)}`}>
                            <SVG src={toAbsoluteUrl("/icons/Shield-protected.svg")} />
                        </span>
                        <span className="menu-text">Policies</span>
                    </NavLink>
                </li>
                <li className={`menu-item ${getMenuItemActive("/quotes", false)}`} aria-haspopup="true">
                    <NavLink className="menu-link" to="/quotes">
                        <span className={`svg-icon ${getActiveSvg("/quotes", false)}`}>
                            <SVG src={toAbsoluteUrl("/icons/Write.svg")} />
                        </span>
                        <span className="menu-text">Quotes</span>
                    </NavLink>
                </li>
                <li className={`menu-item ${getMenuItemActive("/debtors", false)}`} aria-haspopup="true">
                    <NavLink className="menu-link" to="/debtors">
                        <span className={`svg-icon ${getActiveSvg("/debtors", false)}`}>
                            <SVG src={toAbsoluteUrl("/icons/Warning-2.svg")} />
                        </span>
                        <span className="menu-text">Debtors</span>
                    </NavLink>
                </li>
                <li className={`menu-item ${getMenuItemActive("/instructions", false)}`} aria-haspopup="true">
                    <NavLink className="menu-link" to="/instructions">
                        <span className={`svg-icon ${getActiveSvg("/instructions", false)}`}>
                            <SVG src={toAbsoluteUrl("/icons/Clipboard-list.svg")} />
                        </span>
                        <span className="menu-text">Instructions</span>
                    </NavLink>
                </li>
                <li className={`menu-item ${getMenuItemActive("/reports", false)}`} aria-haspopup="true">
                    <NavLink className="menu-link" to="/reports">
                        <span className={`svg-icon ${getActiveSvg("/reports", false)}`}>
                            <SVG src={toAbsoluteUrl("/icons/Equalizer.svg")} />
                        </span>
                        <span className="menu-text">Reports</span>
                    </NavLink>
                </li>
                <li className={`menu-item ${getMenuItemActive("/documents", false)}`} aria-haspopup="true">
                    <NavLink className="menu-link" to="/documents">
                        <span className={`svg-icon ${getActiveSvg("/documents", false)}`}>
                            <SVG src={toAbsoluteUrl("/icons/Archive.svg")} />
                        </span>
                        <span className="menu-text">Documents</span>
                    </NavLink>
                </li>
                <li className={`menu-item ${getMenuItemActive("/aml", false)}`} aria-haspopup="true">
                    <NavLink className="menu-link" to="/aml">
                        <span className={`svg-icon ${getActiveSvg("/aml", false)}`}>
                            <SVG src={toAbsoluteUrl("/icons/Dollar.svg")} />
                        </span>
                        <span className="menu-text">AML</span>
                    </NavLink>
                </li>
            </ul>
        </>
    );
}