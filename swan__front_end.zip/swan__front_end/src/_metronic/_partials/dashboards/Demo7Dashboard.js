import React from "react";

export function Demo7Dashboard() {
    return <></>;
}
