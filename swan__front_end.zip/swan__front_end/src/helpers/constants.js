export const DATE = {
    TIME: 'Time',
    TIME_INTERVAL: 15,
    TWELVE_HRS_FORMAT: 'h:mm A',
    DATE_TIME_FORMAT: ' D/MM/YYYY, h:mm A',
    DATE_ONLY: 'DD/MM/YYYY',
    DATE_FOR_PICKER: 'yyyy/MM/dd',
    DATE_MONTH_ONLY: 'dd/MM',
    DATE_MONTH_ONLY__: 'DD/MM',
    MONTH_ONLY: 'MM',
    YEAR_ONLY: 'yyyy',
    EXAMPLE_DATE: '2017-03-13',
    DATE_FORMAT: 'YYYY-MM-DD',
    DATE_FORMAT_MINS: 'MMM-DD-YYYY, hh:mm',
    DATE_FOR_PICKER_MONTH: 'MM'
  }