// export const ENVIRONMENT = process.env.NODE_ENV;
// export const BASE_URL = process.env.REACT_APP_API_URL;
export const APP_NAME = 'Demo';
export const AUTH_PREFIX = '/auth';
export const APP_PREFIX = '/app';