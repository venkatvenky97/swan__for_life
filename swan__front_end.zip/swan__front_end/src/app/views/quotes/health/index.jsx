import React from 'react'

const Health = () => {

    return (
        <h1>Health....!</h1>
    )
}

export default Health;