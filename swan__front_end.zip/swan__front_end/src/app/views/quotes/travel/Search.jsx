const Search = [
    [
        {
            "client no.": "0004",
            "Last Name": "Hong wan Ban",
            "First Name": "Javin",
            "NIC": "H1829623456"
        },
    
        {
            "client no.": "0004",
            "Last Name": "Hong wan Ban",
            "First Name": "Javin",
            "NIC": "H1829623456"
        },
    
        {
            "client no.": "0004",
            "Last Name": "Hong wan Ban",
            "First Name": "Javin",
            "NIC": "H1829623456"
        }
    
    ]
]
