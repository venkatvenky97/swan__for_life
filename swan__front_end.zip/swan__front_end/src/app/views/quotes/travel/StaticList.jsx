import React from 'react'

import data from "../../../views/quotes/travel/Search"

function Search(props) {
    const filteredData = data.filter((el) => {
        if(props.input === '' ){
            return el;
        } else {
            return el.text.toLowerCae().include(props.input)
        }
    })

    return (
        <ul>
                {/* {filteredData.map((item) => {
                    <li key={item.id} > {item.text}</li>
                })}
             */}
        </ul>
    )
}

export default Search