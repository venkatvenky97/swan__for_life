import React, { useState } from 'react'
import {Grid, Box, Tabs, Tab, Button } from '@material-ui/core'
import Icofont from 'react-icofont'

import StepPersonalDetails from './StepPersonalDetails'
import StepVehicleDetails from './StepVehicleDetails'
import StepExtensions from './StepExtensions'

function TabPanel(props) {
    const { children, value, index, ...other } = props;
    return (
        <div
            role="tabpanel"
            hidden={value !== index}
            id={`full-width-tabpanel-${index}`}
            aria-labelledby={`full-width-tab-${index}`}
            {...other}>
            {value === index && (
                <Box p={3}>
                    {children}
                </Box>
            )}
        </div>
    )
}

const StepMotorSummary = () => {
    
    const [value, setValue] = useState(0);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    }
    return (
        <Grid 
            container 
            direction="row"
            justifyContent="center"
            alignItems="flex-start"
            spacing={4}>
            <Grid item md={5}>
                <section className="travel-summary">
                    <h4>Provisional Quote</h4>
                    <h5>Summary</h5>
                    <ul>
                        <li>Name <span>Javin Badin Hong Wa Ban</span></li>
                        <li>Quote Number: <span>Rs 602</span></li>
                        <li>Quote Date: <span>Rs 1861</span></li>
                        <li>Quote Validity: <span>Rs 250</span></li>
                    </ul>
                    <ul>
                        <div>Premium Details <span></span></div>
                        <li>Discount Pot Balance: <span>Rs 1259</span></li>
                        <li>Discount % <span>Rs 602</span></li>
                    </ul>
                    <div>
                        
                    </div>
                    <ul>
                        <li>Discount Amount: <span>Rs -30</span></li>
                        <li>Policy Fee: <span>Rs 30</span></li>
                        <li>FSC fee: <span>Rs 250</span></li>
                        <li>Premium <span>Rs 30,000</span></li>
                        <li>Total Premium <span>Rs 30,250</span></li>
                    </ul>
                    <div>
                        <Button variant="outlined" color="primary">
                            SEND QUOTE
                        </Button>
                        <Button variant="contained" color="primary">
                            PRINT QUOTATION
                        </Button>
                    </div>
                </section>
            </Grid>
            <Grid item md={7}>
                <section className="quote-summary">
                    <div className="quote-summary-header">
                        <Button href="#text-buttons" color="primary">
                            <Icofont icon="pencil-alt-2"/> &nbsp; EDIT
                        </Button>
                        <Button href="#text-buttons" color="primary">
                            <Icofont icon="download-alt"/> &nbsp; DOWNLOAD QUOTE
                        </Button>
                    </div>
                    <div className="quote-summary-content">
                        <Tabs
                            value={value}
                            indicatorColor="primary"
                            textColor="primary"
                            onChange={handleChange}
                            aria-label="tabs">
                            <Tab label="PERSONAL DETAILS" />
                            <Tab label="VEHICLE DETAILS / EXTENSIONS" />
                            <Tab label="PROPOSAL DETAILS" />
                        </Tabs>
                        <TabPanel value={value} index={0}>
                            <StepPersonalDetails />
                        </TabPanel>
                        <TabPanel value={value} index={1}>
                            <StepVehicleDetails />
                        </TabPanel>
                        <TabPanel value={value} index={2}>                            
                            <StepExtensions />
                        </TabPanel>
                    </div>
                </section>
            </Grid>
        </Grid>
    )
}

export default StepMotorSummary;