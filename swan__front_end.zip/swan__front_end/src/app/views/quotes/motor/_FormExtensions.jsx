import React from 'react'
import { Grid } from "@material-ui/core"
import { useForm } from "react-hook-form";

import Mselect from 'app/form-controls/Mselect'
import Mswitch from 'app/form-controls/Mswitch'

const FormExtensions = () => {
    const { control, handleSubmit, formState: { errors } } = useForm({
        defaultValues: {
            client_number: '',
            nic_number: '',
            title: '',
            first_name: '',
            last_name: '',
            dob: '',
            occupation: '',
            year_of_license: '',
            no_of_claims: ''
        }
    })
    const onSubmit = (data) => {
        console.log("data -", data);
        console.log("errors -", errors);
    }

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <Grid 
                container 
                direction="row"
                justifyContent="center"
                alignItems="flex-start"
                spacing={4}>
                <Grid item md={9}>
                    <Grid 
                        container 
                        direction="row"
                        justifyContent="center"
                        alignItems="flex-start"
                        spacing={5}> 
                        <Grid item md={6}>
                            <Grid 
                                container 
                                spacing={2}> 
                                <Grid item xs={12}>
                                    <h4 className="form-title-md">Extensions</h4>
                                    <p>Extensions are included</p>
                                </Grid>
                                <Mselect xs={12} name="limit_days" label="Limit Days/Amount*" control={control} req/>
                                <Mselect xs={12} name="alternative" label="Alternative*" control={control} req/>
                                <Mselect xs={12} name="driver_fault_compensation" label="Driver At-fault Compensation*" control={control} req/>
                                <Mswitch xs={12} name="replacement_car" label="Replacement car following Breakdown" control={control}/>
                                <Mswitch xs={12} name="excess_waiver" label="Excess Waiver" control={control}/>
                                <Mswitch xs={12} name="alloy_heel" label="Alloy Wheel" control={control}/>
                            </Grid>
                        </Grid>
                        <Grid item md={6}>
                            <Grid 
                                container 
                                spacing={2}>
                                <Grid item xs={12}>
                                    <h4 className="form-title-md">Extras</h4>
                                </Grid>
                                <Mswitch xs={12} name="swan_agreed_repair" label="+Swan Agreed Repairer" control={control}/>
                                <Mswitch xs={12} name="passive_terrer" label="Passive Terrorism" control={control}/>
                                <Mswitch xs={12} name="rodent_damage" label="Rodent Damage" control={control}/>
                                <Mswitch xs={12} name="finance_gap" label="Finance Gap" control={control}/>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
                <Grid item md={3}>
                    <section className="travel-summary">
                        <h4>MOTOR SUMMARY</h4>
                        <h5>Total</h5>
                        <h4>Rs 20,713</h4>
                        <ul>
                            <div>Vehicle Details <span></span></div>
                            <li>Make <span>Rs 1259</span></li>
                            <li>Model <span>Rs 602</span></li>
                            <li>Sub Model <span>Rs 1861</span></li>
                            <li>Engine Capacity <span>Rs 250</span></li>
                            <li>Reg. Month/Year <span>28/2022</span></li>
                        </ul>
                    </section>
                </Grid>
            </Grid>
        </form>
    )
}

export default FormExtensions;