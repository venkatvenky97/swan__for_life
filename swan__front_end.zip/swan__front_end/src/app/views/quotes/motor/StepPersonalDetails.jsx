import React from 'react'
import FormPersonalDetails from './_FormPersonalDetails'

const StepMotorPersonalDetails = () => {
    return (
        <FormPersonalDetails />
    )
}

export default StepMotorPersonalDetails;