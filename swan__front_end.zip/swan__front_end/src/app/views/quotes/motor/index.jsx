import React, { useState } from 'react'
import { Link } from "react-router-dom"
import { Grid, Stepper, Step, StepLabel, Button } from '@material-ui/core';
import Icofont from 'react-icofont'

import StepPersonalDetails from './StepPersonalDetails'
import StepVehicleDetails from './StepVehicleDetails'
import StepExtensions from './StepExtensions'
import StepSummary from './StepSummary'

function getSteps() {
    return [
        'Personal Informations', 
        'Vehicle Details', 
        'Extensions',
        'Quotation Summary'
    ];
}
function getStepContent(stepIndex) {
    switch (stepIndex) {
        case 0:
            return <StepPersonalDetails />;
        case 1:
            return <StepVehicleDetails />;
        case 2:
            return <StepExtensions />;
        case 3:
            return <StepSummary />;
        default:
            return <StepPersonalDetails />;
    }
}

const Motor = () => {
    const [activeStep, setActiveStep] = useState(1);
    const steps = getSteps();

    const handleNext = () => {
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
    }
    const handleBack = () => {
        setActiveStep((prevActiveStep) => prevActiveStep - 1);
    }

    return (
        <section className="quote-create">
            <Grid 
                container 
                direction="row"
                justifyContent="center"
                alignItems="flex-start">
                <Grid item md={10}>
                    <h4 className="section-title"><Link to={'/overview'}><Icofont icon="arrow-left"/></Link> Motor Quotation</h4>
                </Grid>                
            </Grid>
            <Grid 
                container 
                direction="row"
                justifyContent="center"
                alignItems="flex-start">
                <Grid item md={8}>
                    <Stepper activeStep={activeStep} alternativeLabel>
                        {steps.map((label) => (
                            <Step key={label}>
                                <StepLabel>{label}</StepLabel>
                            </Step>
                        ))}
                    </Stepper>
                </Grid>                
            </Grid>
            <Grid 
                container 
                direction="row"
                justifyContent="center"
                alignItems="flex-start">
                <Grid item md={10}>
                    {getStepContent(activeStep)}  
                </Grid>   
                <Grid item md={10} className="txt-right">
                    <Button
                        disabled={activeStep === 0}
                        onClick={handleBack}>
                        Back
                    </Button>
                    <Button variant="contained" color="primary" onClick={handleNext}>
                        {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
                    </Button>  
                </Grid>               
            </Grid>           
        </section>
    )
}

export default Motor;