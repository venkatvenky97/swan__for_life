import React from 'react'
import FormExtensions from './_FormExtensions'

const StepMotorExtensions = () => {

    return (
        <FormExtensions />
    )
}

export default StepMotorExtensions;