import React from 'react'
import { Grid, Radio, FormControlLabel, RadioGroup, Button } from "@material-ui/core"
import { useForm } from "react-hook-form"

import ClientsModals from 'app/modals/ClientsModal'
import Mtextbox from 'app/form-controls/Mtextbox'
import Mselect from 'app/form-controls/Mselect'
import Mswitch from 'app/form-controls/Mswitch'
import Mtextarea from 'app/form-controls/Mtextarea'

const FormPersonalDetails = () => {
    const { control, handleSubmit } = useForm({
        defaultValues: {
            client_number: '',
            nic_number: '',
            title: '',
            first_name: '',
            last_name: '',
            dob: '',
            occupation: '',
            year_of_license: '',
            no_of_claims: ''
        }
    })
    //const { errors } = formState;
    const onSubmit = (data) => {
        console.log("data -", data);
    }

    return (
        <form onSubmit={handleSubmit(onSubmit)}>
            <Grid 
                container 
                direction="row"
                justifyContent="center"
                alignItems="flex-start"
                spacing={4}>
                <Grid item md={12}>
                    <Grid 
                        container 
                        spacing={2} 
                        alignItems="center"> 
                        <Grid item xs={2}>
                            <span>Type of Quotation</span>
                        </Grid>
                        <Grid item xs={6}>
                            <RadioGroup row aria-label="position" name="position" defaultValue="end">                                            
                                <FormControlLabel value="individual" control={<Radio color="primary" />} label="Individual" />
                                <FormControlLabel value="corporate" control={<Radio color="primary" />} label="Corporate" />
                            </RadioGroup>
                        </Grid>
                        <Grid item xs={4} className="txt-right">
                            <ClientsModals />
                        </Grid>
                    </Grid>
                </Grid>
                <Grid item md={6}>
                    <Grid 
                        container 
                        spacing={2}> 
                        <Grid item xs={12}>
                            <h4 className="form-title-md">Personal Information <span>*Required field </span></h4>
                        </Grid>

                        <Mswitch xs={12} name="new_client" label="New Client" control={control}/>

                        <Mtextbox xs={12} name="client_number" label="Client Number" control={control} />
                        <Mtextbox xs={12} name="nic_number" label="NIC Number" control={control} />

                        <Mselect xs={3} name="title" label="Title" control={control} req/>
                        <Mtextbox xs={9} name="first_name" label="First Name*" control={control} req/>

                        <Mtextbox xs={6} name="last_name" label="Last Name" control={control} req/>
                        <Mtextbox xs={6} name="dob" label="Date of Birth*" control={control} req/>

                        <Mselect xs={12} name="occupation" label="Occupation" control={control} req/>
                        <Mswitch xs={12} label="Learner" name="" />

                        <Mselect xs={5} name="year_of_license" label="Year of License*" control={control} req/>
                        <Mtextbox xs={7} name="no_of_claims" label="Total No. Of claims over past 3 years" control={control} />
                    </Grid>
                </Grid>
                <Grid item md={6}>
                    <Grid 
                        container 
                        spacing={2}>
                        <Grid item xs={12}>
                            <h4 className="form-title-md">Contact Details</h4>
                        </Grid>

                        <Mtextbox xs={12} name="mobile_number" label="Mobile Phone*" control={control} req/>
                        <Mtextbox xs={12} name="home_phone_number" label="Home Phone" control={control} />
                        <Mtextbox xs={12} name="email_address" label="Email Address*" control={control} req/>
                        <Mtextarea xs={12} name="remarks" label="Remarks (max 600 chars)" control={control} />
                        
                        <Button type="submit">Submit</Button>
                    </Grid>    
                </Grid>
            </Grid>
        </form>
    )
}

export default FormPersonalDetails;