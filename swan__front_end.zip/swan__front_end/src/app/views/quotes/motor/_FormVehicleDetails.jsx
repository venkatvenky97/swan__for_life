import React, { Fragment } from 'react'
import { Grid, Button } from "@material-ui/core"
import { useForm } from "react-hook-form";

import Mtextbox from 'app/form-controls/Mtextbox'
import Mselect from 'app/form-controls/Mselect'
import Mdatepicker from 'app/form-controls/Mdatepicker'
import Mswitch from 'app/form-controls/Mswitch'

import ValidateNotify from 'app/widgets/ValidateNotify'

const FormVehicleDetails = () => {
    const { control, handleSubmit, formState: { errors } } = useForm({
        defaultValues: {
            purchase_type: '',
            policy_type: '',
            make: '',
            model: '',
            sub_model: '',
            engine_capacity: '',
            register_date: '',
            vehicle_type: '',
            no_of_seat: '',
            register_number: '',            
            vehicle_kept_in: '',
            sum_insured: '',
            trailer_sum_in: '',
            compulsory_xs: '',
            voluntary_xs: '',
            young_driver_xs: ''
        }
    })
    const onSubmit = (data) => {
        console.log("data -", data);
        console.log("errors -", errors);
    }
    return (
        <Fragment>
            <form onSubmit={handleSubmit(onSubmit)}>
                <Grid 
                    container 
                    direction="row"
                    justifyContent="center"
                    alignItems="flex-start"
                    spacing={4}>
                    <Grid item md={6}>
                        <Grid 
                            container 
                            spacing={2}> 
                            <Grid item xs={12}>
                                <h4 className="form-title-md">Vehicle Details <span>*Required field </span></h4>
                            </Grid>
                            <Mselect xs={12} name="purchase_type" label="Purchase Type*" control={control} req/>
                            <Mselect xs={12} name="policy_type" label="Policy Type*" control={control} req/>
                            <Mselect xs={6} name="make" label="Make*" control={control} req/>
                            <Mselect xs={6} name="model" label="Model of Car*" control={control} req/>
                            <Mselect xs={6} name="sub_model" label="Sub-Model*" control={control} req/>
                            <Mtextbox xs={6} name="engine_capacity" label="Engine Capacity (CC)*" control={control} req/>
                            <Mdatepicker xs={12} name="register_date" label="Reg. Month/Year (MM/YYYY)*" control={control} req/>
                            <Mselect xs={7} name="vehicle_type" label="Vehicle Type" control={control}/>
                            <Mselect xs={5} name="no_of_seat" label="Num. of Seat*" control={control} req/>
                            <Mtextbox xs={12} name="register_number" label="Reg No" control={control}/>
                        </Grid>
                    </Grid>
                    <Grid item md={6}>
                        <Grid 
                            container 
                            spacing={2}> 
                            <Mselect xs={12} name="vehicle_kept_in" label="Vehicle kept in*" control={control} req/>
                            <Mtextbox xs={6} name="sum_insured" label="Sum Insured*" control={control} req/>
                            <Mtextbox xs={6} name="trailer_sum_in" label="Trailer Sum Ins." control={control} req/>
                            <Mtextbox xs={6} name="compulsory_xs" label="Compulsory XS*" control={control} req/>
                            <Mselect xs={12} name="voluntary_xs" label="Voluntary XS" control={control} req/>
                            <Mtextbox xs={6} name="young_driver_xs" label="Young Driver XS*" control={control} req/>
                            <Mswitch xs={12} name="security_alaram" label="Security / Alarm?" control={control}/>
                            <Button type="submit">Submit</Button>
                        </Grid>
                    </Grid>
                </Grid>
            </form>
            <ValidateNotify />
        </Fragment>
    )
}

export default FormVehicleDetails;