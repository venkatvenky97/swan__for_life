import React from 'react'

const FormSummaryMotor = () => {

    return (
        <h1>FormSummaryMotor....!</h1>
    )
}

export default FormSummaryMotor;