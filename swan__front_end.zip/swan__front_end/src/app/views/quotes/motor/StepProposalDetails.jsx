import React from 'react'
import FormProposalDetails from './_FormProposalDetails'

const StepMotorProposalDetails = () => {

    return (
        <FormProposalDetails />
    )
}

export default StepMotorProposalDetails;