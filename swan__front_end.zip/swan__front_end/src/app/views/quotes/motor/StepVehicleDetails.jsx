import React from 'react'
import FormVehicleDetails from './_FormVehicleDetails'

const StepMotorVehicleDetails = () => {

    return (
        <FormVehicleDetails />
    )
}

export default StepMotorVehicleDetails;