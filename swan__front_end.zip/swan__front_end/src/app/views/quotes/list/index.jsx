import React from 'react'

const QuoteList = () => {

    return (
        <h1>QuoteList....!</h1>
    )
}

export default QuoteList;