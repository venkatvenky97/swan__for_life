import React from 'react'

const Debtors = () => {

    return (
        <h1>Debtors....!</h1>
    )
}

export default Debtors;