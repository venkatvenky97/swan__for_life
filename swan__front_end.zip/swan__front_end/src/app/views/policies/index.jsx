import React from 'react'

const Policies = () => {

    return (
        <h1>Policies....!</h1>
    )
}

export default Policies;