import React from 'react'

const Instructions = () => {

    return (
        <h1>Instructions....!</h1>
    )
}

export default Instructions;