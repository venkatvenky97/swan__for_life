import React from 'react'

const Aml = () => {

    return (
        <h1>Aml....!</h1>
    )
}

export default Aml;