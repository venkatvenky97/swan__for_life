export const toAbsoluteUrl = (pathname) => pathname
