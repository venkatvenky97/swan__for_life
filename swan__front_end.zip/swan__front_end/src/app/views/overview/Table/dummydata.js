export const dummydata = [
    { id: 1, product: 'George', client: 'Monkey' },
    { id: 2, product: 'Jeffrey', client: 'Giraffe' },
    { id: 3, product: 'Alice', client: 'Giraffe' },
    { id: 4, product: 'Foster', client: 'Tiger' },
    { id: 5, product: 'Tracy', client: 'Bear' },
    { id: 6, product: 'Joesph', client: 'Lion' },
    { id: 7, product: 'Tania', client: 'Deer' },
    { id: 8, product: 'Chelsea', client: 'Tiger' },
    { id: 9, product: 'Benedict', client: 'Tiger' },
    { id: 10, product: 'Chadd', client: 'Lion' },
    { id: 11, product: 'Delphine', client: 'Deer' },
    { id: 12, product: 'Elinore', client: 'Bear' },
    { id: 13, product: 'Stokes', client: 'Tiger' },
    { id: 14, product: 'Tamara', client: 'Lion' },
    { id: 15, product: 'Zackery', client: 'Bear' }
  ]

  export const columns = [
    { dataField: 'id', text: 'Quotation ID', sort: true },
    { dataField: 'product', text: 'Product', sort: true },
    { dataField: 'client', text: 'client', sort: true }
  ];