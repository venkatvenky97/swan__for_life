import React from 'react'

const Documents = () => {

    return (
        <h1>Documents....!</h1>
    )
}

export default Documents;