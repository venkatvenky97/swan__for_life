import React from 'react'
import { Popover } from "@material-ui/core"

const InfoPopup = () => {

    return (
        <Popover 
            anchorOrigin={{
                vertical: 'top',
                horizontal: 'center',
            }}
            transformOrigin={{
                vertical: 'bottom',
                horizontal: 'center',
            }}>
            The content of the Popover.
        </Popover>
    )
}

export default InfoPopup;