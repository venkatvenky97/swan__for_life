import React, { useState } from 'react';
import { Grid } from "@material-ui/core"

const ValidateNotify = (props) => {
	const [state, setState] = useState({
    	open: true,
    	vertical: 'bottom',
    	horizontal: 'left',
  	})
  	const { vertical, horizontal, open } = state;

  	const handleClose = () => {
    	setState({ ...state, open: false });
  	}

    return (
    	<section className="validation-widget">
	        <Grid 
	            container 
	            direction="row"
	            justifyContent="center"
	            alignItems="flex-start"
	            spacing={2}>
				<Grid item xs={10}>
					<p>Please fill in required <br />information to proceed</p>
				</Grid>
				<Grid item xs={2}>
					CLOSE
				</Grid>
			</Grid>
		</section>
    )
}

export default ValidateNotify;