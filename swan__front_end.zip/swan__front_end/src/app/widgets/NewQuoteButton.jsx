import React, { useRef, useState, useEffect } from 'react'
import Icofont from 'react-icofont'
import { Link } from "react-router-dom"

import Button from '@material-ui/core/Button';
import ClickAwayListener from '@material-ui/core/ClickAwayListener';
import Grow from '@material-ui/core/Grow';
import Paper from '@material-ui/core/Paper';
import Popper from '@material-ui/core/Popper';
import MenuItem from '@material-ui/core/MenuItem';
import MenuList from '@material-ui/core/MenuList';

const NewQuoteButton = () => {
    const [open, setOpen] = useState(false)
    const anchorRef = useRef(null)
    const prevOpen = useRef(open);

    const handleToggle = () => {
        setOpen((prevOpen) => !prevOpen);
    }
    const handleClose = (event) => {
        if (anchorRef.current && anchorRef.current.contains(event.target)) {
            return;
        }
        setOpen(false);
    }
    function handleListKeyDown(event) {
        if (event.key === 'Tab') {
            event.preventDefault();
            setOpen(false);
        }
    }

    useEffect(() => {
        if (prevOpen.current === true && open === false) {
            anchorRef.current.focus();
        }
        prevOpen.current = open;
    }, [open]);

    return (
        <div className="new-quote-widget">
            <Button
                ref={anchorRef}
                aria-controls={open ? 'menu-list-grow' : undefined}
                aria-haspopup="true"
                onClick={handleToggle}
                variant="contained"
                color="primary"
                className="quote-blue-btn rounded">
                <Icofont icon="pencil-alt-5"/> &nbsp; &nbsp; Make a New quote
            </Button>
            <Popper open={open} anchorEl={anchorRef.current} role={undefined} transition disablePortal>
                {({ TransitionProps, placement }) => (
                    <Grow
                        {...TransitionProps}
                        style={{ transformOrigin: placement === 'bottom' ? 'center top' : 'center bottom' }}
                    >
                    <Paper>
                        <ClickAwayListener onClickAway={handleClose}>
                            <MenuList autoFocusItem={open} id="menu-list-grow" onKeyDown={handleListKeyDown}>
                                <MenuItem>
                                    <Link to={"/quotes/motor"}>Motor <span><Icofont icon="car-alt-3"/></span></Link>
                                </MenuItem>
                                <MenuItem>
                                    <Link to={"/quotes/health"}>Health <span><Icofont icon="heart-beat"/></span></Link>
                                </MenuItem>
                                <MenuItem>
                                    <Link to={"/quotes/home"}>Home <span><Icofont icon="home"/></span></Link>
                                </MenuItem>
                                <MenuItem>
                                    <Link to={"/quotes/travel"}>Travel <span><Icofont icon="heart"/></span></Link>
                                </MenuItem>
                            </MenuList>
                        </ClickAwayListener>
                    </Paper>
                </Grow>
            )}
            </Popper>
        </div>
    )
}

export default NewQuoteButton;