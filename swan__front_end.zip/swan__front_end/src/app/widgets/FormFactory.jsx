import React, { Fragment } from "react";
import Minput from 'app/form-controls/Minput'
import Mselect from 'app/form-controls/Mselect'

const FormFactory = (props) => {
    const { fieldId, className } = props;

    const renderElement = () => {
        switch (fieldType) {
            case "text":
                return <Minput {...props}/>;
            case "select":
                return <Mselect {...props}/>
            default:
                return <Minput {...props}/>;
        }
    };

    return (
        <Grid item xs={12}>
            {FormElement()}
        </Grid>
    );
};

export default FormFactory;