import React from 'react'
import { Grid, FormControl, InputLabel, MenuItem, Select } from "@material-ui/core"
import { Controller } from "react-hook-form"

const Mselect = ({xs, name, control, label, req}) => {

    return (
        <Grid item xs={xs}>
            <FormControl variant="outlined" className="m-select">
                <InputLabel>{label}</InputLabel>
                <Controller
                    name={name}
                    control={control}
                    rules={{
                        required: req? true : false
                    }}
                    render={({ 
                        field: { onChange, value },
                        fieldState: { error },
                        formState, 
                    }) => (
                        <Select 
                            onChange={onChange} 
                            value={value}
                            error={!!error}>
                            <MenuItem value="">
                                <em>None</em>
                            </MenuItem>
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    )}
                />
            </FormControl>
        </Grid>
    )
}

export default Mselect;