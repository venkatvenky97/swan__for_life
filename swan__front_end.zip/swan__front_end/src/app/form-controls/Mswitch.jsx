import React from 'react'
import { Grid, FormControlLabel, Switch } from "@material-ui/core";
// import { Controller } from "react-hook-form";

const Mswitch = ({xs, name, control, label}) => {
    const handleChange = () =>{

    }
    return (
        <Grid item xs={12}>
            <Grid 
                container 
                alignItems="center" 
                spacing={1}>
                <Grid item xs={9}>{label}</Grid>
                <Grid item>No</Grid>
                <Grid item>
                    <FormControlLabel className="m-switch" control={<Switch onChange={handleChange} name={name} />}/>
                </Grid>
                <Grid item>Yes</Grid>
            </Grid>
        </Grid>
    )
}

export default Mswitch;