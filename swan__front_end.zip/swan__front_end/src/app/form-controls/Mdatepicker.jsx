import React from "react";
import { Grid } from "@material-ui/core"
import DateFnsUtils from "@date-io/date-fns";
import { KeyboardDatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import { Controller } from "react-hook-form";
const DATE_FORMAT = "MMM-yy";

const Mdatepicker = ({ xs, name, control, label }) => {

    const [selectedDate, setSelectedDate] = React.useState(new Date('2014-08-18T21:11:54'));

  const handleDateChange = (date) => {
    setSelectedDate(date);
  };
    return (
        <Grid item xs={xs}>
            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                <KeyboardDatePicker
                    id={name}
                    label={label}
                    inputVariant="outlined"
                    format="MM/dd/yyyy"
                    value={selectedDate}
                    onChange={handleDateChange}
                    KeyboardButtonProps={{
                        "aria-label": "change date"
                    }}
                />
              </MuiPickersUtilsProvider>
        </Grid>
    );
}

export default Mdatepicker;