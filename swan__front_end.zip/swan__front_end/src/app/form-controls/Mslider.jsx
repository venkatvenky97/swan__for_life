import React, { useEffect, useState } from "react";
import { Grid, FormLabel, Slider } from "@material-ui/core";
import { Controller } from "react-hook-form";

const Mslider = ({xs, name, label }) => {
    
    return ( 
        <Grid item xs={xs}>
            <Slider
                defaultValue={30}
                getAriaValueText={"30"}
                aria-labelledby="discrete-slider"
                valueLabelDisplay="auto"
                step={10}
                marks
                min={10}
                max={110}
              />
        </Grid>
    );
};

export default Mslider;