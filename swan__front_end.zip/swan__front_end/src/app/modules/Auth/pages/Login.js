import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useFormik, Formik, Form, Field } from "formik";
import * as Yup from "yup";
import { connect } from "react-redux";
import { FormattedMessage, injectIntl } from "react-intl";
import * as auth from "../_redux/authRedux";
import { login } from "../_redux/authCrud";
import swan_logo from "../assets/swan_logo.svg"
import Color from "../assets/Color.svg"
import '../assets/style.css';
import { TextField } from "formik-material-ui"
import { Grid, Box, Button } from "@material-ui/core"
/*
  INTL (i18n) docs:
  https://github.com/formatjs/react-intl/blob/master/docs/Components.md#formattedmessage
*/

/*
  Formik+YUP:
  https://jaredpalmer.com/formik/docs/tutorial#getfieldprops
*/

const initialValues = {
    email: "admin@demo.com",
    password: "demo",
};

function Login(props) {
    const { intl } = props;
    const [loading, setLoading] = useState(false);
    const [passwordType, setPasswordType] = useState("password");
    const LoginSchema = Yup.object().shape({
        email: Yup.string()
            .email("Wrong email format")
            .min(3, "Minimum 3 symbols")
            .max(50, "Maximum 50 symbols")
            .required(
                intl.formatMessage({
                    id: "AUTH.VALIDATION.REQUIRED_FIELD",
                })
            ),
        password: Yup.string()
            .min(3, "Minimum 3 symbols")
            .max(50, "Maximum 50 symbols")
            .required(
                intl.formatMessage({
                    id: "AUTH.VALIDATION.REQUIRED_FIELD",
                })
            ),
    });

    const enableLoading = () => {
        setLoading(true);
    };

    const disableLoading = () => {
        setLoading(false);
    };

    const getInputClasses = (fieldname) => {
        if (formik.touched[fieldname] && formik.errors[fieldname]) {
            return "is-invalid";
        }

        if (formik.touched[fieldname] && !formik.errors[fieldname]) {
            return "is-valid";
        }

        return "";
    };

    const formik = useFormik({
        initialValues,
        validationSchema: LoginSchema,
        onSubmit: (values, { setStatus, setSubmitting }) => {
            enableLoading();
            setTimeout(() => {
                login(values.email, values.password)
                    .then(({ data: { authToken } }) => {
                        disableLoading();

                        props.login(authToken);
                    })
                    .catch(() => {
                        setStatus(
                            intl.formatMessage({
                                id: "AUTH.VALIDATION.INVALID_LOGIN",
                            })
                        );
                    })
                    .finally(() => {
                        disableLoading();
                        setSubmitting(false);
                    });
            }, 1000);
        },
    });

    const togglePassword = () => {
        if (passwordType === "password") {
            setPasswordType("text")
            return;
        }
        setPasswordType("password")
    }

    return (
        <div className="login-form login-signin" id="kt_login_signin_form">
            <div className="text-center mb-10 mb-lg-20">
                <h3 className="font-size-h1">
                    <img src={swan_logo} alt="swan_logo" className="max-h-70px" id="AUTH.LOGIN.TITLE" />
                </h3>
            </div>
            <Formik
                initialValues={{
                    email: "admin@demo.com", //not Material UI. Works.
                    password: "demo" //from Material UI
                }}
                onSubmit={(values, actions) => {
                    enableLoading();
                    setTimeout(() => {
                        login(values.email, values.password)
                            .then(({ data: { authToken } }) => {
                                disableLoading();
                                props.login(authToken);
                                console.log(authToken)
                            })
                            .catch(() => {
                                console.log("validate error")
                                // setStatus(
                                //     intl.formatMessage({
                                //         id: "AUTH.VALIDATION.INVALID_LOGIN",
                                //     })
                                // );
                            })
                            .finally(() => {
                                disableLoading();
                                //setSubmitting(false);
                            });
                    }, 1000);
                }}>
                {({ dirty, isValid, values, handleChange, handleBlur }) => {
                    return (
                        <Form className="login-form">
                            <Grid 
                                container 
                                direction="row"
                                alignItems="flex-start"
                                spacing={3}>
                                <Grid item md={12}>
                                    <Field
                                        label="USERNAME"
                                        variant="outlined"
                                        fullWidth
                                        name="email"
                                        value={values.email}
                                        component={TextField}
                                    />
                                </Grid> 
                                <Grid item md={12}>
                                    <Field
                                        label="PASSWORD"
                                        variant="outlined"
                                        fullWidth
                                        type="password"
                                        name="password"
                                        value={values.password}
                                        component={TextField}
                                    />
                                </Grid> 
                                <Grid item md={12} className="txt-center">
                                    <Link className="blu-link" to={""}>FORGOT PASSWORD</Link>
                                </Grid> 
                                <Grid item md={12}>
                                    <Grid 
                                        container 
                                        direction="row"
                                        justifyContent="center"
                                        spacing={3}>
                                        <Grid item md={10}>
                                            <Button variant="contained" size="medium" color="primary" type="submit">
                                                LOGIN
                                            </Button> 
                                        </Grid> 
                                    </Grid>   
                                </Grid>   
                            </Grid>    
                        </Form>
                    )
                }}
            </Formik>
        </div>
    );
}

export default injectIntl(connect(null, auth.actions)(Login));