import React, { useState, Fragment } from 'react'
import Icofont from 'react-icofont'
import { Button, Dialog, DialogTitle, DialogContent, DialogActions } from "@material-ui/core"
import IconButton from "@material-ui/core/IconButton";
import SearchBar from "material-ui-search-bar";

import TextField from "@material-ui/core/TextField";
import StaticList from "../views/quotes/travel/StaticList"
import Jsondata from '../views/quotes/travel/searchData.json'


// import DynamicTable from "../views/quotes/travel/DynamicTable"
// import Search  from 'app/views/quotes/travel/Search';

const ClientsModals = () => {
    const [open, setOpen] = useState(false);
    const [inputText, setInputText] = useState("");

    const handleClickOpen = () => {
      setOpen(true);
  }
  const handleClose = () => {
      setOpen(false);
  }

   
  const inputHandler = (e) => {
alert('Workings')   
    // var lowerCase = e.target.value.toLowerCase();
    // setInputText(lowerCase);
    // console.log('demo', lowerCase)
  };


    return (
      <Fragment>
        <Button
          variant="contained"
          color="primary"
          className="quote-blue-btn"
          onClick={handleClickOpen}
        >
          <Icofont icon="search" /> &nbsp; FIND EXISTING CLIENTS
        </Button>
        <Dialog
          fullWidth={true}
          maxWidth={"sm"}
          open={open}
          onClose={handleClose}
          aria-labelledby="form-dialog-title"
        >
          <DialogTitle id="form-dialog-title">Search for clients</DialogTitle>
          <DialogContent>
            <SearchBar
              placeholder="Search clients by name,date of birth,NYC"
           
              InputProps={{
                endAdornment: (
                  <IconButton>
                    <TextField
                      id="outlined-basic"
                      onChange={inputHandler}
                      variant="outlined"
                      fullWidth
                      label="Search"
                      
                    />
                    <JsonData />
                     <StaticList input={inputText} />
               
                  </IconButton>
                  
                  
                ),
              }}
            />

          </DialogContent>
          <DialogActions>
            <Button
              variant="contained"
              className="quote-blue-btn"
              onClick={handleClose}
              color="primary"
            >
              Close
            </Button>
          </DialogActions>
        </Dialog>
      </Fragment>
    );
}

export default ClientsModals;